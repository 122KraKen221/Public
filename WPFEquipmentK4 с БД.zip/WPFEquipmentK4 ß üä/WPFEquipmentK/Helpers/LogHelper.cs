﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFEquipmentK.Helpers
{
    public class LogHelper
    {
        public static void LogAction(string actionDescription)
        {
            using (var db = new Diplom7Entities())
            {
                var log = new UserLogs
                {
                    ActionDate = DateTime.Now,
                    UserID = UserClass.userID, 
                    Action = actionDescription
                };
                db.UserLogs.Add(log);
                db.SaveChanges();
            }
        }
    }
}
