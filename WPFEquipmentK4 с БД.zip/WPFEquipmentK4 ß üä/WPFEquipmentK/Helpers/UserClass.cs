﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFEquipmentK.Helpers
{
    internal class UserClass
    {
        public static int userID;
        public static string userName;
        public static string password;
        public static string email;
        public static int RoleID;
    }
}
