﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;

namespace WPFEquipmentK.Helpers
{
    internal class EmailService
    {
        private readonly string smtpHost = "smtp.mail.ru";
        private readonly int smtpPort = 587;
        private readonly string fromEmail = "sasha.zhag@mail.ru";
        private readonly string fromPassword = "qjTQ1u0uMihh6z2SdGR1"; // пароль приложения

        public void SendRepairRequestEmail(string toEmail, string equipmentName, string serialNumber)
        {
            var subject = "Новая заявка на ремонт";
            var body = $"Поступила новая заявка на ремонт оборудования:\n\n" +
                       $"Наименование: {equipmentName}\n" +
                       $"Серийный номер: {serialNumber}\n" +
                       $"Расположение: {GetEquipmentPlacement(serialNumber)}";

            SendEmail(toEmail, subject, body);
        }

        public void SendTechnicianAssignedEmail(string toEmail, string equipmentName, string serialNumber, string technicianName)
        {
            var subject = "Назначение на заявку по ремонту";
            var body = $"Уважаемый {technicianName},\n\n" +
                      $"Вы были назначены на заявку по ремонту оборудования:\n\n" +
                      $"Наименование: {equipmentName}\n" +
                      $"Серийный номер: {serialNumber}\n" +
                      $"Расположение: {GetEquipmentPlacement(serialNumber)}\n\n" +
                      $"Пожалуйста, приступите к выполнению заявки.";

            SendEmail(toEmail, subject, body);
        }

        public void SendRequestStatusUpdateEmail(string toEmail, string equipmentName, string serialNumber, string status, string comment = "")
        {
            var statusText = status == "Выполнено" ? "выполнена" : "отклонена";
            var subject = $"Обновление статуса заявки на ремонт - {status}";
            var body = $"Уважаемый пользователь,\n\n" +
                      $"Ваша заявка на ремонт оборудования была {statusText}:\n\n" +
                      $"Наименование: {equipmentName}\n" +
                      $"Серийный номер: {serialNumber}\n" +
                      $"Расположение: {GetEquipmentPlacement(serialNumber)}";

            if (!string.IsNullOrEmpty(comment))
            {
                body += $"\nКомментарий: {comment}";
            }

            SendEmail(toEmail, subject, body);
        }

        private void SendEmail(string toEmail, string subject, string body)
        {
            try
            {
                using (var client = new SmtpClient(smtpHost, smtpPort))
                {
                    client.EnableSsl = true;
                    client.Credentials = new NetworkCredential(fromEmail, fromPassword);

                    var message = new MailMessage(fromEmail, toEmail, subject, body);
                    client.Send(message);
                }
            }
            catch (Exception ex)
            {
                // Логируем ошибку, но не прерываем работу программы
                Console.WriteLine($"Ошибка отправки email: {ex.Message}");
            }
        }

        private string GetEquipmentPlacement(string serialNumber)
        {
            using (var db = new Diplom7Entities())
            {
                var equipment = db.Equipment.FirstOrDefault(e => e.SerialNumber == serialNumber);
                return equipment?.Placement ?? "Не указано";
            }
        }
    }
}
