USE master;
GO

-- Проверяем, существует ли база данных
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'Diplom7')
BEGIN
    -- Если база существует, удаляем её
    DROP DATABASE Diplom7;
END
GO

-- Создаем базу данных
CREATE DATABASE Diplom7
ON PRIMARY (
    NAME = 'Diplom7',
    FILENAME = 'D:\WPFEquipmentK4 с БД\WPFEquipmentK\bin\Release\DataBase.mdf\Diplom7.mdf',
    SIZE = 10MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10%
)
LOG ON (
    NAME = 'Diplom7_log',
    FILENAME = 'D:\WPFEquipmentK4 с БД\WPFEquipmentK\bin\Release\DataBase.mdf\Diplom7_log.ldf',
    SIZE = 5MB,
    MAXSIZE = UNLIMITED,
    FILEGROWTH = 10%
);
GO

USE Diplom7;
GO

-- Создаем таблицы
CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL
);

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    UserName NVARCHAR(100) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) NOT NULL,
    RoleID INT NOT NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleID) REFERENCES Roles(RoleID)
);

CREATE TABLE Equipment (
    EquipmentID INT IDENTITY(1,1) PRIMARY KEY,
    EquipmentName NVARCHAR(100) NOT NULL,
    SerialNumber NVARCHAR(50) NOT NULL,
    Model NVARCHAR(100) NOT NULL,
    Manufacturer NVARCHAR(100) NOT NULL,
    PurchaseDate DATE NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    Placement NCHAR(50) NOT NULL
);

CREATE TABLE RepairRequests (
    RequestID INT IDENTITY(1,1) PRIMARY KEY,
    EquipmentID INT NOT NULL,
    RequestDate DATE NOT NULL,
    RequestedBy INT NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    AssignedTo INT NULL,
    Description NVARCHAR(500) NOT NULL,
    EndDate DATE NULL,
    CONSTRAINT FK_RepairRequests_Equipment FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID),
    CONSTRAINT FK_RepairRequests_RequestedBy FOREIGN KEY (RequestedBy) REFERENCES Users(UserID),
    CONSTRAINT FK_RepairRequests_AssignedTo FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);

CREATE TABLE UserLogs (
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NOT NULL,
    Action NVARCHAR(255) NOT NULL,
    ActionDate DATETIME NULL,
    CONSTRAINT FK_UserLogs_Users FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Добавляем базовые роли
INSERT INTO Roles (RoleName) VALUES ('Администратор');
INSERT INTO Roles (RoleName) VALUES ('Пользователь');
GO 