﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;

namespace WPFEquipmentK.Windows
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    using System;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows;

    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = RegUsernameTextBox.Text;
            string email = EmailTextBox.Text;
            string password = RegPasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Все поля должны быть заполнены!");
                return;
            }

            // Проверка формата email
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Неверный формат email адреса!");
                return;
            }

            // Проверка на минимальную и максимальную длину логина
            if (username.Length < 6)
            {
                MessageBox.Show("Логин должен содержать минимум 6 символов!");
                return;
            }
            if (username.Length > 25)
            {
                MessageBox.Show("Логин не должен превышать 25 символов!");
                return;
            }

            // Проверка на минимальную длину и требования к паролю
            if (!IsValidPassword(password))
            {
                MessageBox.Show("Пароль должен содержать минимум 6 символов, одну заглавную букву и хотя бы одну цифру!");
                return;
            }

            // Проверка на совпадение паролей
            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            string hashedPassword = HashPassword(password);

            var db = AppConnect.ConnectDB;
            if (db.Users.Any(u => u.UserName == username))
            {
                MessageBox.Show("Такой пользователь уже существует!");
                return;
            }

            if (db.Users.Any(u => u.Email == email))
            {
                MessageBox.Show("Этот email уже зарегистрирован!");
                return;
            }

            Users user = new Users()
            {
                UserName = username,
                Email = email,
                PasswordHash = hashedPassword,
                RoleID = 4 // Роль пользователя
            };
            db.Users.Add(user);
            db.SaveChanges();

            MessageBox.Show("Регистрация успешна!");
            this.Close();
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPassword(string password)
        {
            var regex = new Regex(@"^(?=.*[A-Z])(?=.*\d).{6,}$");
            return regex.IsMatch(password);
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private void Box_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Блокируем ввод пробела
            }
        }


    }


}
