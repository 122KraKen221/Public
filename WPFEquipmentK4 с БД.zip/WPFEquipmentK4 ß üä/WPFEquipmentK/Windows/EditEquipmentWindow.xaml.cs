﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;

namespace WPFEquipmentK.Windows
{
    /// <summary>
    /// Логика взаимодействия для EditEquipmentWindow.xaml
    /// </summary>
    public partial class EditEquipmentWindow : Window
    {
        private Equipment _currentEquipment;
        private bool _isNew;

        public EditEquipmentWindow(Equipment equipment)
        {
            InitializeComponent();
            _isNew = equipment == null;
            _currentEquipment = _isNew ? new Equipment() : new Equipment
            {
                EquipmentID = equipment.EquipmentID,
                EquipmentName = equipment.EquipmentName,
                SerialNumber = equipment.SerialNumber,
                Model = equipment.Model,
                Manufacturer = equipment.Manufacturer,
                PurchaseDate = equipment.PurchaseDate,
                Status = equipment.Status,
                Placement = equipment.Placement
            };

            DataContext = _currentEquipment;

            if (_isNew)
            {
                PurchaseDatePicker.SelectedDate = DateTime.Today;
                StatusComboBox.SelectedIndex = 0; // Устанавливаем "Рабочее" по умолчанию
            }
            else
            {
                if (UserClass.RoleID == 4)
                {
                    EquipmentNameTextBox.Visibility = Visibility.Collapsed;
                    SerialNumberTextBox.Visibility = Visibility.Collapsed;
                    ModelTextBox.Visibility = Visibility.Collapsed;
                    ManufacturerTextBox.Visibility = Visibility.Collapsed;
                    PurchaseDatePicker.Visibility = Visibility.Collapsed;
                }
                EquipmentNameTextBox.Text = _currentEquipment.EquipmentName;
                SerialNumberTextBox.Text = _currentEquipment.SerialNumber;
                ModelTextBox.Text = _currentEquipment.Model;
                ManufacturerTextBox.Text = _currentEquipment.Manufacturer;
                PurchaseDatePicker.SelectedDate = _currentEquipment.PurchaseDate;
                StatusComboBox.SelectedValue = _currentEquipment.Status;
                PlacementTextBox.Text = _currentEquipment.Placement;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EquipmentNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(SerialNumberTextBox.Text) ||
                string.IsNullOrWhiteSpace(ModelTextBox.Text) ||
                string.IsNullOrWhiteSpace(ManufacturerTextBox.Text) ||
                string.IsNullOrWhiteSpace(PlacementTextBox.Text) ||
                !PurchaseDatePicker.SelectedDate.HasValue ||
                StatusComboBox.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var db = AppConnect.ConnectDB; // Получаем контекст из GetContext()

            string selectedStatus = StatusComboBox.SelectedItem.ToString().Replace("System.Windows.Controls.ComboBoxItem: ", "");

            if (_isNew)
            {
                var newEquipment = new Equipment
                {
                    EquipmentName = EquipmentNameTextBox.Text,
                    SerialNumber = SerialNumberTextBox.Text,
                    Model = ModelTextBox.Text,
                    Manufacturer = ManufacturerTextBox.Text,
                    PurchaseDate = PurchaseDatePicker.SelectedDate.Value,
                    Status = selectedStatus,
                    Placement = PlacementTextBox.Text
                };

                db.Equipment.Add(newEquipment);
                db.SaveChanges(); // Сохраняем изменения, чтобы получить ID
                LogHelper.LogAction($"Создано оборудование ID:{newEquipment.EquipmentID} - {newEquipment.EquipmentName} (Модель: {newEquipment.Model}, Производитель: {newEquipment.Manufacturer}, Расположение: {newEquipment.Placement})");
            }
            else
            {
                var existingEquipment = db.Equipment.Find(_currentEquipment.EquipmentID);
                if (existingEquipment != null)
                {
                    existingEquipment.EquipmentName = EquipmentNameTextBox.Text;
                    existingEquipment.SerialNumber = SerialNumberTextBox.Text;
                    existingEquipment.Model = ModelTextBox.Text;
                    existingEquipment.Manufacturer = ManufacturerTextBox.Text;
                    existingEquipment.PurchaseDate = PurchaseDatePicker.SelectedDate.Value;
                    existingEquipment.Status = selectedStatus;
                    existingEquipment.Placement = PlacementTextBox.Text;
                }
                LogHelper.LogAction($"Изменено оборудование ID:{existingEquipment.EquipmentID} - {existingEquipment.EquipmentName} (Модель: {existingEquipment.Model}, Производитель: {existingEquipment.Manufacturer}, Расположение: {existingEquipment.Placement})");
            }

            db.SaveChanges(); // Сохраняем изменения через общий контекст

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
