﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using WPFEquipmentK.Pages;

namespace WPFEquipmentK.Windows
{

    public partial class EditRepairRequestWindow : Window
    {
        private RepairRequests _repairRequest; // Текущая заявка
        private bool _isEditMode; // Режим редактирования
        private Diplom7Entities _dbContext; // Контекст БД
        private Equipment _selectedEquipment; // Выбранное оборудование

        public EditRepairRequestWindow(RepairRequests repairRequest, Equipment selectedEquipment = null)
        {
            InitializeComponent();
            _repairRequest = repairRequest;
            _selectedEquipment = selectedEquipment;
            _dbContext = new Diplom7Entities();
            _isEditMode = _repairRequest != null;

            DataContext = _repairRequest;
            LoadStatuses();
            LoadEquipment();

            if (_isEditMode)
            {
                EquipmentComboBox.SelectedValuePath = "EquipmentID";
                EquipmentComboBox.SelectedValue = (int)_repairRequest.EquipmentID;
                DescriptionTextBox.Text = _repairRequest.Description;
                RequestDatePicker.SelectedDate = _repairRequest.RequestDate;
                StatusComboBox.SelectedItem = _repairRequest.Status;
                StatusComboBox.Visibility = Visibility.Visible;
            }
            else
            {
                // В режиме создания заявки
                StatusComboBox.SelectedItem = "Ожидает";
                StatusComboBox.Visibility = Visibility.Hidden;
                TxtStatus.Visibility = Visibility.Hidden;
                
                // Устанавливаем текущую дату и делаем её неизменяемой
                RequestDatePicker.SelectedDate = DateTime.Now;
                RequestDatePicker.IsEnabled = false;

                // Если есть выбранное оборудование, устанавливаем его
                if (_selectedEquipment != null)
                {
                    var equipment = ((List<Equipment>)EquipmentComboBox.ItemsSource)
                        .FirstOrDefault(e => e.EquipmentID == _selectedEquipment.EquipmentID);
                    if (equipment != null)
                    {
                        EquipmentComboBox.SelectedItem = equipment;
                    }
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentComboBox.SelectedItem == null ||
                string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show("Заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            using (var db = new Diplom7Entities())
            {
                if (_isEditMode)
                {
                    var existingRequest = db.RepairRequests
                        .Include("Equipment")
                        .Include("Users1")
                        .FirstOrDefault(x => x.RequestID == _repairRequest.RequestID);

                    if (existingRequest != null)
                    {
                        var equipment = db.Equipment.Find(((Equipment)EquipmentComboBox.SelectedItem).EquipmentID);
                        
                        // Сохраняем старый статус для сравнения
                        var oldStatus = existingRequest.Status;
                        var newStatus = StatusComboBox.SelectedItem as string;
                        
                        existingRequest.EquipmentID = ((Equipment)EquipmentComboBox.SelectedItem).EquipmentID;
                        existingRequest.Description = DescriptionTextBox.Text;
                        existingRequest.RequestDate = RequestDatePicker.SelectedDate ?? DateTime.Now;
                        existingRequest.RequestedBy = UserClass.userID;
                        existingRequest.Status = newStatus;

                        // Если статус изменился, обновляем статус оборудования и отправляем уведомление
                        if (oldStatus != newStatus)
                        {
                            if (newStatus == "Выполнено")
                            {
                                existingRequest.Equipment.Status = "Рабочее";
                                existingRequest.EndDate = DateTime.Now;
                                LogHelper.LogAction($"Изменен статус заявки ID:{existingRequest.RequestID} на 'Выполнено' для оборудования ID:{equipment.EquipmentID} - {equipment.EquipmentName}");
                            }
                            else if (newStatus == "Отклонено")
                            {
                                existingRequest.Equipment.Status = "Неисправное";
                                existingRequest.EndDate = DateTime.Now;
                                LogHelper.LogAction($"Изменен статус заявки ID:{existingRequest.RequestID} на 'Отклонено' для оборудования ID:{equipment.EquipmentID} - {equipment.EquipmentName}");
                            }

                            // Отправляем уведомление создателю заявки
                            var creator = existingRequest.Users1;
                            if (creator != null && !string.IsNullOrEmpty(creator.Email))
                            {
                                AppConnect.emailService.SendRequestStatusUpdateEmail(
                                    creator.Email,
                                    existingRequest.Equipment.EquipmentName,
                                    existingRequest.Equipment.SerialNumber,
                                    newStatus,
                                    existingRequest.Description
                                );
                            }
                        }

                        db.SaveChanges();
                    }
                }
                else
                {
                    var selectedEquipment = (Equipment)EquipmentComboBox.SelectedItem;
                    var creator = db.Users.Find(UserClass.userID);
                    var newRequest = new RepairRequests
                    {
                        EquipmentID = selectedEquipment.EquipmentID,
                        Description = DescriptionTextBox.Text,
                        RequestDate = RequestDatePicker.SelectedDate ?? DateTime.Now,
                        RequestedBy = creator.UserID,
                        Status = "Ожидает",
                        AssignedTo = null,
                        Users1 = creator
                    };

                    db.RepairRequests.Add(newRequest);
                    db.SaveChanges(); // Сохраняем, чтобы получить ID заявки
                    var equipment = db.Equipment.Find(newRequest.EquipmentID);
                    LogHelper.LogAction($"Создана новая заявка ID:{newRequest.RequestID} для оборудования ID:{equipment.EquipmentID} - {equipment.EquipmentName}");
                }
                this.DialogResult = true;
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Закрытие окна без сохранения
            this.Close();
        }

        private void LoadEquipment()
        {
            try
            {
                if (_isEditMode)
                {
                    EquipmentComboBox.ItemsSource = _dbContext.Equipment.Where(x => x.Status == "На ремонте").ToList();
                }
                else
                {
                    var availableEquipment = _dbContext.Equipment.Where(x => 
                        x.Status == "Рабочее" || x.Status == "Неисправное").ToList();
                    EquipmentComboBox.ItemsSource = availableEquipment;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки оборудования: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadStatuses()
        {
            StatusComboBox.ItemsSource = new[] { "Выполнено", "Отклонено" };
        }
    }
}
