﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using WPFEquipmentK.Helpers;
using WPFEquipmentK.Windows;
using System.Data.Entity;

namespace WPFEquipmentK.Pages
{
    /// <summary>
    /// Логика взаимодействия для RepairRequestPage.xaml
    /// </summary>
    public partial class RepairRequestPage : Page
    {
        private RepairRequests SelectedRequest;
        public ObservableCollection<Users> Technicians { get; set; }
        public bool IsManager { get; set; }
        private bool _isInitializing = true;
        private bool _isSelectionChanging = false;
        private bool _isPageLoaded = false;
        private bool _isFirstLoad = true;
        private DateTime _lastSelectionTime = DateTime.MinValue;

        public RepairRequestPage()
        {
            InitializeComponent();
            _isInitializing = true;
            _isPageLoaded = false;
            _isFirstLoad = true;
            
            LoadTechnicians();
            SetColumnVisibility();

            // Автоматически включаем галку для администратора и менеджера
            if (UserClass.RoleID == 1 || UserClass.RoleID == 4)
            {
                ShowAllRequestsCheckBox.IsChecked = true;
                HideCompletedRequestsCheckBox.IsEnabled = false;
            }
            else if (UserClass.RoleID == 3) // Для техников
            {
                HideCompletedRequestsCheckBox.IsChecked = true;
            }

            var equipmentList = AppConnect.ConnectDB.Equipment.Select(e => new { e.EquipmentID, e.EquipmentName }).ToList();
            equipmentList.Insert(0, new { EquipmentID = 0, EquipmentName = "Выберите оборудование" });
            EquipmentComboBox.ItemsSource = equipmentList;
            EquipmentComboBox.DisplayMemberPath = "EquipmentName";
            EquipmentComboBox.SelectedValuePath = "EquipmentID";
            EquipmentComboBox.SelectedIndex = 0;

            var listStatus = AppConnect.ConnectDB.RepairRequests.Select(x => x.Status).Distinct().ToList();
            StatusComboBox.Items.Add("Выберите статус");
            foreach (var item in listStatus)
            {
                StatusComboBox.Items.Add(item);
            }
            StatusComboBox.SelectedIndex = 0;

            UbdateDb();
            
            _isInitializing = false;
            _isPageLoaded = true;
            _isFirstLoad = false;
        }

        private void SetColumnVisibility()
        {
            // Проверяем, является ли пользователь менеджером (RoleID == 2) или администратором (RoleID == 1)
            IsManager = UserClass.RoleID == 2 || UserClass.RoleID == 1;
            
            // Обновляем DataContext для применения изменений
            this.DataContext = this;
        }

        private void RepairRequestsDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedRequest = RepairRequestsDataGrid.SelectedItem as RepairRequests;
            
            // Обновляем состояние кнопок в зависимости от статуса заявки
            if (SelectedRequest != null)
            {
                bool canEdit = SelectedRequest.Status != "Выполнено";
                EditButton.IsEnabled = canEdit;
                DeleteButton.IsEnabled = canEdit;
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addRequestWindow = new EditRepairRequestWindow(null);

            if (addRequestWindow.ShowDialog() == true)
            {
                // Обновляем статус оборудования на "Неисправное"
                var db = AppConnect.ConnectDB;
                var newRequest = db.RepairRequests
                    .Include("Equipment")
                    .OrderByDescending(x => x.RequestID)
                    .FirstOrDefault();

                if (newRequest != null && newRequest.Equipment != null)
                {
                    newRequest.Equipment.Status = "Неисправное";
                    db.SaveChanges();
                }

                ClassFrame.FrmObj.Navigate(new RepairRequestPage());
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedRequest == null)
            {
                MessageBox.Show("Выберите заявку для редактирования.", "Предупреждение");
                return;
            }

            // Проверяем статус заявки
            if (SelectedRequest.Status == "Выполнено")
            {
                MessageBox.Show("Нельзя редактировать выполненную заявку.", "Предупреждение");
                return;
            }

            var editRequestWindow = new EditRepairRequestWindow(SelectedRequest);

            if (editRequestWindow.ShowDialog() == true)
            {
                ClassFrame.FrmObj.Navigate(new RepairRequestPage());
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedRequest = RepairRequestsDataGrid.SelectedItem as RepairRequests;
                if (selectedRequest == null)
                {
                    MessageBox.Show("Пожалуйста, выберите заявку для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var result = MessageBox.Show("Вы уверены, что хотите удалить эту заявку?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    using (var db = new Diplom7Entities())
                    {
                        // Находим заявку в базе данных
                        var requestToDelete = db.RepairRequests.Find(selectedRequest.RequestID);
                        if (requestToDelete == null)
                        {
                            MessageBox.Show("Заявка не найдена в базе данных.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        // Удаляем заявку
                        db.RepairRequests.Remove(requestToDelete);
                        db.SaveChanges();

                        // Логируем действие
                        LogHelper.LogAction($"Удалена заявка ID:{selectedRequest.RequestID}");

                        // Обновляем отображение
                        UbdateDb();
                        MessageBox.Show("Заявка успешно удалена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении заявки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            RepairRequestsDataGrid.Items.Refresh();
            ClassFrame.FrmObj.Navigate(new MenuPage());
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UbdateDb();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UbdateDb();
        }

        private void ShowAllRequestsCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (!_isInitializing)
            {
                AppConnect.ConnectDB.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                UbdateDb();
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                _isPageLoaded = true;
                UbdateDb();
            }
            else
            {
                _isPageLoaded = false;
            }
        }

        private void UbdateDb()
        {
            try
            {
                using (var db = new Diplom7Entities())
                {
                    var currentReq = db.RepairRequests
                        .Include("Equipment")
                        .Include("Users")  // Для техника (AssignedTo)
                        .Include("Users1") // Для создателя (RequestedBy)
                        .OrderByDescending(x => x.RequestDate)
                        .ToList();

                    // Если пользователь - техник и чекбокс не отмечен, показываем только его заявки
                    if (UserClass.RoleID == 3 && ShowAllRequestsCheckBox.IsChecked != true)
                    {
                        currentReq = currentReq.Where(x => x.AssignedTo == UserClass.userID).ToList();
                    }

                    // Если чекбокс "Скрыть выполненные заявки" отмечен, скрываем выполненные заявки
                    if (HideCompletedRequestsCheckBox.IsChecked == true)
                    {
                        currentReq = currentReq.Where(x => x.Status != "Выполнено").ToList();
                    }

                    // Фильтрация по тексту поиска
                    if (!string.IsNullOrWhiteSpace(SearchTextBox.Text))
                    {
                        string searchText = SearchTextBox.Text.ToLower();
                        currentReq = currentReq.Where(x => x.Description.ToLower().Contains(searchText)).ToList();
                    }

                    // Фильтрация по оборудованию
                    if (EquipmentComboBox.SelectedIndex > 0)
                    {
                        currentReq = currentReq.Where(x => x.EquipmentID == Convert.ToInt32(EquipmentComboBox.SelectedValue)).ToList();
                    }

                    // Фильтрация по статусу
                    if (StatusComboBox.SelectedIndex > 0)
                    {
                        currentReq = currentReq.Where(x => x.Status == StatusComboBox.SelectedValue.ToString()).ToList();
                    }

                    RepairRequestsDataGrid.ItemsSource = null;
                    RepairRequestsDataGrid.ItemsSource = currentReq;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTechnicians()
        {
            try
            {
                var db = AppConnect.ConnectDB;
                var technicians = db.Users.Where(u => u.RoleID == 3).ToList();
                Technicians = new ObservableCollection<Users>(technicians);
                this.DataContext = this;
                System.Diagnostics.Debug.WriteLine($"Loaded {Technicians.Count} technicians");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке списка техников: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CmbTech_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("SelectionChanged event triggered");
            
            // Игнорируем события во время инициализации и первой загрузки
            if (_isInitializing || _isFirstLoad || !_isPageLoaded || _isSelectionChanging)
            {
                System.Diagnostics.Debug.WriteLine("Ignoring event due to initialization flags");
                return;
            }

            try
            {
                _isSelectionChanging = true;
                System.Diagnostics.Debug.WriteLine("Starting technician assignment process");

                var comboBox = sender as ComboBox;
                if (comboBox == null)
                {
                    System.Diagnostics.Debug.WriteLine("ComboBox is null");
                    return;
                }

                var selectedUserID = comboBox.SelectedValue as int?;
                if (!selectedUserID.HasValue)
                {
                    System.Diagnostics.Debug.WriteLine("Selected UserID is null");
                    return;
                }
                System.Diagnostics.Debug.WriteLine($"Selected UserID: {selectedUserID}");

                var repairRequest = comboBox.DataContext as RepairRequests;
                if (repairRequest == null)
                {
                    System.Diagnostics.Debug.WriteLine("RepairRequest is null");
                    return;
                }
                System.Diagnostics.Debug.WriteLine($"Processing request ID: {repairRequest.RequestID}");

                // Создаем новый контекст для обновления
                using (var db = new Diplom7Entities())
                {
                    var existingRequest = db.RepairRequests.Find(repairRequest.RequestID);
                    if (existingRequest == null)
                    {
                        System.Diagnostics.Debug.WriteLine($"Request not found in database: {repairRequest.RequestID}");
                        return;
                    }

                    // Получаем информацию о технике
                    var technician = db.Users.Find(selectedUserID.Value);
                    if (technician == null)
                    {
                        System.Diagnostics.Debug.WriteLine($"Technician not found: {selectedUserID}");
                        return;
                    }
                    System.Diagnostics.Debug.WriteLine($"Found technician: {technician.UserName}");

                    // Проверяем, действительно ли изменился техник
                    if (existingRequest.AssignedTo == selectedUserID)
                    {
                        System.Diagnostics.Debug.WriteLine("Same technician selected - no change needed");
                        return;
                    }

                    // Обновляем заявку
                    existingRequest.AssignedTo = selectedUserID;
                    existingRequest.Status = "Назначено";
                    System.Diagnostics.Debug.WriteLine($"Updated request with technician ID: {selectedUserID}");
                    
                    // Обновляем статус оборудования
                    var equipment = db.Equipment.Find(existingRequest.EquipmentID);
                    if (equipment != null)
                    {
                        equipment.Status = "На ремонте";
                        System.Diagnostics.Debug.WriteLine($"Updated equipment status to 'На ремонте'");
                    }

                    // Сохраняем изменения
                    try
                    {
                        var result = db.SaveChanges();
                        System.Diagnostics.Debug.WriteLine($"SaveChanges result: {result} entities modified");

                        // Логируем действие
                        LogHelper.LogAction($"Назначен исполнитель {technician.UserName} на заявку ID:{existingRequest.RequestID}");

                        // Отправляем уведомление
                        if (!string.IsNullOrEmpty(technician.Email))
                        {
                            AppConnect.emailService.SendTechnicianAssignedEmail(
                                technician.Email,
                                equipment?.EquipmentName ?? "Неизвестное оборудование",
                                equipment?.SerialNumber ?? "Неизвестный серийный номер",
                                technician.UserName
                            );
                        }

                        // Получаем обновленные данные перед закрытием контекста
                        var updatedRequest = db.RepairRequests
                            .Include("Equipment")
                            .Include("Users")
                            .Include("Users1")
                            .FirstOrDefault(r => r.RequestID == existingRequest.RequestID);

                        // Обновляем отображение
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            try
                            {
                                // Обновляем данные в UI
                                UbdateDb();
                                MessageBox.Show($"Техник {technician.UserName} успешно назначен на заявку.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                System.Diagnostics.Debug.WriteLine("UI updated and success message shown");
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine($"Error updating UI: {ex.Message}");
                                MessageBox.Show($"Ошибка при обновлении отображения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }));
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"Error saving changes: {ex.Message}");
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in CmbTech_SelectionChanged: {ex.Message}");
                MessageBox.Show($"Ошибка при назначении техника: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _isSelectionChanging = false;
                System.Diagnostics.Debug.WriteLine("Selection change process completed");
            }
        }

        private void StatusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isInitializing) return;

            var comboBox = sender as ComboBox;
            if (comboBox?.SelectedItem == null || comboBox.SelectedIndex == 0) return;

            var selectedStatus = comboBox.SelectedItem.ToString();
            var repairRequest = (RepairRequests)RepairRequestsDataGrid.SelectedItem;

            if (repairRequest != null)
            {
                try
                {
                    var db = AppConnect.ConnectDB;
                    var existingRequest = db.RepairRequests
                        .Include("Equipment")
                        .Include("Users1")
                        .FirstOrDefault(x => x.RequestID == repairRequest.RequestID);

                    if (existingRequest != null)
                    {
                        // Обновляем статус заявки
                        existingRequest.Status = selectedStatus;

                        // Обновляем статус оборудования в зависимости от статуса заявки
                        if (selectedStatus == "Выполнено")
                        {
                            existingRequest.Equipment.Status = "Рабочее";
                            existingRequest.EndDate = DateTime.Now;
                        }
                        else if (selectedStatus == "Отклонено")
                        {
                            existingRequest.Equipment.Status = "Неисправное";
                            existingRequest.EndDate = DateTime.Now;
                        }

                        // Получаем информацию о создателе заявки
                        var creator = existingRequest.Users1;
                        if (creator != null && !string.IsNullOrEmpty(creator.Email))
                        {
                            // Отправляем уведомление создателю заявки
                            AppConnect.emailService.SendRequestStatusUpdateEmail(
                                creator.Email,
                                existingRequest.Equipment.EquipmentName,
                                existingRequest.Equipment.SerialNumber,
                                selectedStatus,
                                existingRequest.Description
                            );
                        }

                        db.SaveChanges();
                        AppConnect.ConnectDB.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                        UbdateDb();

                        MessageBox.Show($"Статус заявки успешно обновлен на '{selectedStatus}'", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении статуса: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
