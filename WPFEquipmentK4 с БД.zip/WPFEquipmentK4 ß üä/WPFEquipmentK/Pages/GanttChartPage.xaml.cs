using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;

namespace WPFEquipmentK.Pages
{
    public partial class GanttChartPage : Page
    {
        private const double ROW_HEIGHT = 40;
        private const double BAR_HEIGHT = 30;
        private const double DAY_WIDTH = 30;
        private const double MARGIN = 10;
        private const double TEXT_WIDTH = 200;
        private const int DAYS_TO_SHOW = 31;
        private const int ITEMS_PER_PAGE = 20;
        private const double BAR_SPACING = 5;
        private const double HEADER_HEIGHT = 30;

        private int currentPage = 0;
        private List<Equipment> allEquipment;
        private List<RepairRequests> allRepairRequests;
        private DateTime startDate;

        public GanttChartPage()
        {
            InitializeComponent();
            LoadGanttChart();
        }

        private void LoadGanttChart()
        {
            try
            {
                using (var db = new Diplom7Entities())
                {
                    allEquipment = db.Equipment.ToList();
                    allRepairRequests = db.RepairRequests
                        .Include("Equipment")
                        .Include("Users")
                        .OrderBy(x => x.RequestDate)
                        .ToList();

                    if (!allEquipment.Any())
                    {
                        MessageBox.Show("Нет данных для отображения", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    // Устанавливаем начальную дату на первое число текущего месяца
                    startDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                    DisplayCurrentPage();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке диаграммы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DisplayCurrentPage()
        {
            try
            {
                // Очищаем Canvas
                GanttCanvas.Children.Clear();

                if (allEquipment == null || allRepairRequests == null)
                {
                    MessageBox.Show("Данные не загружены", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Получаем оборудование для текущей страницы
                var pageEquipment = allEquipment
                    .Skip(currentPage * ITEMS_PER_PAGE)
                    .Take(ITEMS_PER_PAGE)
                    .ToList();

                // Вычисляем общую высоту Canvas
                double totalHeight = HEADER_HEIGHT + MARGIN + (pageEquipment.Count * ROW_HEIGHT) + MARGIN;
                GanttCanvas.Height = totalHeight;

                // Вычисляем ширину Canvas (31 день)
                double totalWidth = TEXT_WIDTH + (DAYS_TO_SHOW * DAY_WIDTH);
                GanttCanvas.Width = totalWidth;

                // Добавляем сетку дней в заголовок
                for (int i = 0; i < DAYS_TO_SHOW; i++)
                {
                    var x = TEXT_WIDTH + (i * DAY_WIDTH);

                    // Добавляем дату
                    var dateText = new TextBlock
                    {
                        Text = (i + 1).ToString(),
                        FontSize = 10,
                        Margin = new Thickness(2, 0, 0, 0),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Width = DAY_WIDTH - 4
                    };
                    Canvas.SetLeft(dateText, x);
                    Canvas.SetTop(dateText, 0);
                    GanttCanvas.Children.Add(dateText);

                    // Добавляем месяц, если это первый день месяца
                    if (i == 0)
                    {
                        var monthText = new TextBlock
                        {
                            Text = startDate.ToString("MMMM yyyy"),
                            FontSize = 10,
                            FontWeight = FontWeights.Bold,
                            Margin = new Thickness(2, 15, 0, 0),
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Width = DAY_WIDTH * 3 // Увеличиваем ширину для месяца
                        };
                        Canvas.SetLeft(monthText, x);
                        Canvas.SetTop(monthText, 15);
                        GanttCanvas.Children.Add(monthText);
                    }
                }

                double currentTop = HEADER_HEIGHT + MARGIN;
                foreach (var equipment in pageEquipment)
                {
                    // Добавляем линии сетки для этой строки
                    for (int i = 0; i < DAYS_TO_SHOW; i++)
                    {
                        var x = TEXT_WIDTH + (i * DAY_WIDTH);
                        var gridLine = new Line
                        {
                            X1 = x,
                            Y1 = currentTop,
                            X2 = x,
                            Y2 = currentTop + ROW_HEIGHT,
                            Stroke = Brushes.LightGray,
                            StrokeThickness = 1
                        };
                        GanttCanvas.Children.Add(gridLine);
                    }

                    // Добавляем название оборудования
                    var equipmentText = new TextBlock
                    {
                        Text = equipment.EquipmentName,
                        Width = TEXT_WIDTH - MARGIN,
                        TextWrapping = TextWrapping.Wrap
                    };
                    Canvas.SetLeft(equipmentText, MARGIN);
                    Canvas.SetTop(equipmentText, currentTop + (ROW_HEIGHT - BAR_HEIGHT) / 2);
                    GanttCanvas.Children.Add(equipmentText);

                    // Получаем заявки для этого оборудования за текущий месяц
                    var equipmentRequests = allRepairRequests
                        .Where(r => r.Equipment.EquipmentID == equipment.EquipmentID &&
                                   ((r.RequestDate <= startDate.AddMonths(1).AddDays(-1) && // Заявка началась до или в текущем месяце
                                    (!r.EndDate.HasValue || r.EndDate.Value >= startDate)))) // И либо не закончилась, либо закончилась после начала текущего месяца
                        .OrderBy(r => r.RequestDate)
                        .ToList();

                    // Группируем заявки по пересекающимся периодам
                    var overlappingGroups = new List<List<RepairRequests>>();
                    foreach (var request in equipmentRequests)
                    {
                        var endDate = request.EndDate?.Date ?? DateTime.Now.Date;
                        var addedToGroup = false;

                        // Проверяем, можно ли добавить заявку в существующую группу
                        foreach (var group in overlappingGroups)
                        {
                            var groupOverlaps = group.Any(r => 
                            {
                                var groupEndDate = r.EndDate?.Date ?? DateTime.Now.Date;
                                return (request.RequestDate <= groupEndDate && endDate >= r.RequestDate);
                            });

                            if (groupOverlaps)
                            {
                                group.Add(request);
                                addedToGroup = true;
                                break;
                            }
                        }

                        // Если заявка не пересекается ни с одной группой, создаем новую группу
                        if (!addedToGroup)
                        {
                            overlappingGroups.Add(new List<RepairRequests> { request });
                        }
                    }

                    // Добавляем полосы для каждой группы пересекающихся заявок
                    foreach (var group in overlappingGroups)
                    {
                        var requests = group.OrderBy(r => r.RequestDate).ToList();
                        
                        for (int i = 0; i < requests.Count; i++)
                        {
                            var request = requests[i];
                            var requestStartDate = request.RequestDate.Date;
                            var requestEndDate = request.EndDate?.Date ?? DateTime.Now.Date;
                            
                            // Определяем даты начала и конца отображения для текущего месяца
                            var displayStartDate = requestStartDate < startDate ? startDate : requestStartDate;
                            var displayEndDate = requestEndDate > startDate.AddMonths(1).AddDays(-1) ? 
                                startDate.AddMonths(1).AddDays(-1) : requestEndDate;

                            // Если заявка не активна в текущем месяце, пропускаем её
                            if (displayStartDate > displayEndDate)
                            {
                                continue;
                            }
                            
                            // Вычисляем позицию X для начала заявки
                            var dayOfMonth = displayStartDate.Day;
                            var startX = TEXT_WIDTH + ((dayOfMonth - 1) * DAY_WIDTH);
                            
                            // Вычисляем высоту для каждой полосы в группе
                            var barHeight = (BAR_HEIGHT - (requests.Count - 1) * BAR_SPACING) / requests.Count;
                            
                            // Вычисляем количество дней для отображения
                            var daysToEnd = (displayEndDate - displayStartDate).TotalDays + 1;
                            var width = Math.Max(daysToEnd * DAY_WIDTH, DAY_WIDTH);

                            var bar = new Rectangle
                            {
                                Width = width,
                                Height = barHeight,
                                Fill = GetStatusColor(request.Status),
                                Stroke = Brushes.Black,
                                StrokeThickness = 1
                            };

                            // Вычисляем позицию Y для текущей полосы
                            var barTop = currentTop + (ROW_HEIGHT - BAR_HEIGHT) / 2 + i * (barHeight + BAR_SPACING);
                            
                            // Устанавливаем позицию полоски
                            Canvas.SetLeft(bar, startX);
                            Canvas.SetTop(bar, barTop);
                            GanttCanvas.Children.Add(bar);

                            // Создаем контейнер для подсказки
                            var tooltipContainer = new Border
                            {
                                Width = width,
                                Height = barHeight,
                                Background = Brushes.Transparent
                            };
                            Canvas.SetLeft(tooltipContainer, startX);
                            Canvas.SetTop(tooltipContainer, barTop);
                            GanttCanvas.Children.Add(tooltipContainer);

                            // Добавляем подсказку
                            var tooltip = new ToolTip
                            {
                                Content = $"Заявка #{request.RequestID}\n" +
                                         $"Статус: {request.Status}\n" +
                                         $"Дата начала: {request.RequestDate:dd.MM.yyyy}\n" +
                                         $"Дата окончания: {(request.EndDate?.ToString("dd.MM.yyyy") ?? "Не завершена")}\n" +
                                         $"Техник: {(request.Users?.UserName ?? "Не назначен")}"
                            };
                            tooltipContainer.ToolTip = tooltip;
                        }
                    }

                    currentTop += ROW_HEIGHT;
                }

                // Обновляем навигационные кнопки
                UpdateNavigationButtons();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отображении страницы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateNavigationButtons()
        {
            var totalPages = (int)Math.Ceiling(allEquipment.Count / (double)ITEMS_PER_PAGE);
            BtnPrevPage.IsEnabled = currentPage > 0;
            BtnNextPage.IsEnabled = currentPage < totalPages - 1;
        }

        private void BtnPrevPage_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 0)
            {
                currentPage--;
                DisplayCurrentPage();
            }
        }

        private void BtnNextPage_Click(object sender, RoutedEventArgs e)
        {
            var totalPages = (int)Math.Ceiling(allEquipment.Count / (double)ITEMS_PER_PAGE);
            if (currentPage < totalPages - 1)
            {
                currentPage++;
                DisplayCurrentPage();
            }
        }

        private void BtnPrevDate_Click(object sender, RoutedEventArgs e)
        {
            startDate = startDate.AddMonths(-1);
            DisplayCurrentPage();
            MainScrollViewer.ScrollToHorizontalOffset(0);
        }

        private void BtnNextDate_Click(object sender, RoutedEventArgs e)
        {
            startDate = startDate.AddMonths(1);
            DisplayCurrentPage();
            MainScrollViewer.ScrollToHorizontalOffset(0);
        }

        private Brush GetStatusColor(string status)
        {
            switch (status)
            {
                case "Выполнено":
                    return new SolidColorBrush(Color.FromRgb(146, 208, 80)); // Зеленый
                case "Отклонено":
                    return new SolidColorBrush(Color.FromRgb(255, 0, 0)); // Красный
                default:
                    return new SolidColorBrush(Color.FromRgb(200, 200, 200)); // Серый
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Очищаем текущие данные
                allEquipment = null;
                allRepairRequests = null;
                GanttCanvas.Children.Clear();

                // Перезагружаем данные
                LoadGanttChart();

                // Обновляем навигационные кнопки
                UpdateNavigationButtons();

                MessageBox.Show("Диаграмма успешно обновлена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении диаграммы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
} 