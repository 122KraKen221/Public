﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace WPFEquipmentK.Pages
{
    /// <summary>
    /// Логика взаимодействия для LogsPage.xaml
    /// </summary>
    public partial class LogsPage : System.Windows.Controls.Page
    {

        public LogsPage()
        {
            InitializeComponent();
            LoadLogs();
        }

        private void LoadLogs(string actionFilter = null)
        {
            using (var db = new Diplom7Entities())
            {
                // Получаем базовый запрос логов с информацией о пользователях
                var query = db.UserLogs
                    .Join(db.Users,
                        log => log.UserID,
                        user => user.UserID,
                        (log, user) => new
                        {
                            log.LogID,
                            log.ActionDate,
                            log.Action,
                            UserName = user.UserName
                        });

                // Применяем фильтр по типу действия
                if (!string.IsNullOrEmpty(actionFilter) && actionFilter != "Все действия")
                {
                    query = query.Where(log => 
                        (actionFilter == "Добавление" && (log.Action.Contains("Создано") || log.Action.Contains("Создана"))) ||
                        (actionFilter == "Изменение" && (log.Action.Contains("Изменен") || log.Action.Contains("статус"))) ||
                        (actionFilter == "Удаление" && log.Action.Contains("Удален")) ||
                        (actionFilter == "Назначение" && log.Action.Contains("Назначен"))
                    );
                }

                var logsWithDetails = query
                    .OrderByDescending(log => log.ActionDate)
                    .ToList();

                // Получаем списки оборудования и заявок для поиска дополнительной информации
                var equipment = db.Equipment.ToDictionary(e => e.EquipmentID, e => e.EquipmentName);
                var requests = db.RepairRequests.ToDictionary(r => r.RequestID, r => new { r.EquipmentID, r.Status });
                var users = db.Users.ToDictionary(u => u.UserID, u => u.UserName);

                // Форматируем результаты с дополнительной информацией
                var formattedLogs = logsWithDetails.Select(log =>
                {
                    var action = log.Action;
                    
                    // Ищем ID оборудования в действии
                    var equipmentIdMatch = System.Text.RegularExpressions.Regex.Match(action, @"ID:(\d+)");
                    if (equipmentIdMatch.Success)
                    {
                        int equipmentId;
                        if (int.TryParse(equipmentIdMatch.Groups[1].Value, out equipmentId) && equipment.ContainsKey(equipmentId))
                        {
    
                            
                        }
                    }

                    // Ищем ID заявки в действии
                    var requestIdMatch = System.Text.RegularExpressions.Regex.Match(action, @"заявки: (\d+)");
                    if (requestIdMatch.Success)
                    {
                        int requestId;
                        if (int.TryParse(requestIdMatch.Groups[1].Value, out requestId) && requests.ContainsKey(requestId))
                        {
                            var request = requests[requestId];
                            var equipmentName = equipment.ContainsKey(request.EquipmentID) ? equipment[request.EquipmentID] : "Неизвестно";
                            
                            if (action.Contains("статус"))
                            {
                                action = $"Изменен статус заявки: {requestId} (Оборудование: {equipmentName}) на '{request.Status}'";
                            }
                            else if (action.Contains("Назначен"))
                            {
                                var assignedToMatch = System.Text.RegularExpressions.Regex.Match(action, @"пользователя (\d+)");
                                if (assignedToMatch.Success)
                                {
                                    int userId;
                                    if (int.TryParse(assignedToMatch.Groups[1].Value, out userId) && users.ContainsKey(userId))
                                    {
                                        action = $"Назначен исполнитель {users[userId]} на заявку: {requestId} (Оборудование: {equipmentName})";
                                    }
                                }
                            }
                            else
                            {
                                action = action.Replace($"заявки: {requestId}", $"заявки: {requestId} (Оборудование: {equipmentName})");
                            }
                        }
                    }

                    return new
                    {
                        log.LogID,
                        ActionDate = log.ActionDate != null ? log.ActionDate.Value.ToString("dd.MM.yyyy HH:mm:ss") : "",
                        Action = action,
                        log.UserName
                    };
                }).ToList();

                LogsDataGrid.ItemsSource = formattedLogs;
                UpdateStatistics(formattedLogs);
            }
        }

        private void UpdateStatistics(IEnumerable<dynamic> logs)
        {
            int totalActions = logs.Count();
            int additions = logs.Count(l => l.Action.Contains("Создано") || l.Action.Contains("Создана"));
            int changes = logs.Count(l => l.Action.Contains("Изменен") || l.Action.Contains("статус"));
            int deletions = logs.Count(l => l.Action.Contains("Удален"));
            int assignments = logs.Count(l => l.Action.Contains("Назначен"));

            TotalActionsText.Text = $"Всего действий: {totalActions}";
            AdditionsText.Text = $"Добавлений: {additions}";
            ChangesText.Text = $"Изменений: {changes}";
            DeletionsText.Text = $"Удалений: {deletions}";
            CreatedText.Text = $"Назначений: {assignments}";
            CreatedText.Visibility = Visibility.Visible;
        }

        private string FormatAction(string action, string equipmentName)
        {
            if (string.IsNullOrEmpty(action))
                return "Нет описания";

            if (action.Contains("Добавлено"))
                return $"Добавлено новое оборудование: {equipmentName}";
            else if (action.Contains("Изменены"))
                return $"Изменены данные оборудования: {equipmentName}";
            else if (action.Contains("Удалены"))
                return $"Удалены данные оборудования: {equipmentName}";
            else if (action.Contains("Создана"))
                return $"Создана новая запись: {equipmentName}";
            else
                return action;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Действие при нажатии кнопки "Назад"
            ClassFrame.FrmObj.GoBack();
        }

        private void ActionTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded && ActionTypeComboBox != null && ActionTypeComboBox.SelectedItem != null)
            {
                string actionFilter = ((ComboBoxItem)ActionTypeComboBox.SelectedItem).Content.ToString();
                LoadLogs(actionFilter);
            }
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var excelApp = new Microsoft.Office.Interop.Excel.Application();
                Workbook workbook = null;
                Worksheet worksheet = null;

                try
                {
                    // Получаем данные из DataGrid
                    var logs = LogsDataGrid.ItemsSource as IEnumerable<dynamic>;
                    if (logs == null || !logs.Any())
                    {
                        MessageBox.Show("Нет данных для экспорта.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    excelApp.Visible = false;
                    workbook = excelApp.Workbooks.Add();
                    worksheet = workbook.ActiveSheet;

                    // Заголовки
                    worksheet.Cells[1, 1] = "Дата действия";
                    worksheet.Cells[1, 2] = "Пользователь";
                    worksheet.Cells[1, 3] = "Описание действия";

                    // Форматирование заголовков
                    var headerRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 3]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = 0xC0C0C0; // Светло-серый цвет в формате RGB

                    // Данные
                    int row = 2;
                    foreach (var log in logs)
                    {
                        worksheet.Cells[row, 1] = log.ActionDate;
                        worksheet.Cells[row, 2] = log.UserName;
                        worksheet.Cells[row, 3] = log.Action;
                        row++;
                    }

                    // Автоподбор ширины колонок
                    worksheet.Columns.AutoFit();

                    // Сохранение
                    string fileName = $"Logs_Export_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                    string path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), fileName);
                    workbook.SaveAs(path);

                    MessageBox.Show($"Экспорт успешно завершен.\nФайл сохранен: {path}", "Экспорт", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                finally
                {
                    // Закрытие и освобождение ресурсов
                    if (worksheet != null)
                    {
                        Marshal.ReleaseComObject(worksheet);
                    }
                    if (workbook != null)
                    {
                        workbook.Close();
                        Marshal.ReleaseComObject(workbook);
                    }
                    if (excelApp != null)
                    {
                        excelApp.Quit();
                        Marshal.ReleaseComObject(excelApp);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
