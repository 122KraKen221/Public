﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using WPFEquipmentK.Windows;

namespace WPFEquipmentK.Pages
{
    /// <summary>
    /// Логика взаимодействия для EquipmentPage.xaml
    /// </summary>
    public partial class EquipmentPage : Page
    {
        private ListCollectionView _collectionView;
        private List<Equipment> _equipmentList;

        public EquipmentPage()
        {
            InitializeComponent();
            LoadEquipment();

            if (UserClass.RoleID == 4) 
            { 
                BtnAdd.Visibility = Visibility.Collapsed;
                BtnEdit.Visibility = Visibility.Collapsed;
                BtnDel.Visibility = Visibility.Collapsed;
            }
        }

        private void LoadEquipment()
        {
            var db = AppConnect.ConnectDB;
            _equipmentList = AppConnect.ConnectDB.Equipment.ToList();

            _collectionView = new ListCollectionView(_equipmentList);
            EquipmentDataGrid.ItemsSource = _collectionView;
            _collectionView.Filter = FilterEquipment;

            LoadComboBoxData();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            EditEquipmentWindow editWindow = new EditEquipmentWindow(null);
            if (editWindow.ShowDialog() == true)
            {
                LoadEquipment();
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentDataGrid.SelectedItem is Equipment selectedEquipment)
            {
                EditEquipmentWindow editWindow = new EditEquipmentWindow(selectedEquipment);

                if (editWindow.ShowDialog() == true)
                {
                    LoadEquipment();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите оборудование для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentDataGrid.SelectedItem is Equipment selectedEquipment)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить это оборудование?",
                                             "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    var db = AppConnect.ConnectDB;
                    if (selectedEquipment != null)
                    {
                        LogHelper.LogAction($"Удалено оборудование ID:{selectedEquipment.EquipmentID} - {selectedEquipment.EquipmentName} (Модель: {selectedEquipment.Model}, Производитель: {selectedEquipment.Manufacturer})");
                        db.Equipment.Remove(selectedEquipment);
                        db.SaveChanges();
                        MessageBox.Show("Оборудование успешно удалено!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadEquipment();
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService != null)
            {
                NavigationService.GoBack();
            }
        }
        private void LoadComboBoxData()
        {
            ManufacturerComboBox.ItemsSource = new List<string> { "" }
                .Concat(_equipmentList.Select(e => e.Manufacturer).Distinct()).ToList();

            StatusComboBox.ItemsSource = new List<string> { "" }
                .Concat(_equipmentList.Select(e => e.Status).Distinct()).ToList();
        }

        private bool FilterEquipment(object item)
        {
            if (item is Equipment equipment)
            {
                string searchText = SearchTextBox.Text.Trim().ToLower();
                string selectedManufacturer = ManufacturerComboBox.SelectedItem as string;
                DateTime? selectedPurchaseDate = PurchaseDatePicker.SelectedDate;
                string selectedStatus = StatusComboBox.SelectedItem as string;

                bool isTodaySelected = selectedPurchaseDate.HasValue && selectedPurchaseDate.Value.Date == DateTime.Today;

                bool matchesSearch = string.IsNullOrWhiteSpace(searchText) ||
                                     equipment.EquipmentName.ToLower().Contains(searchText) ||
                                     equipment.Manufacturer.ToLower().Contains(searchText) ||
                                     equipment.SerialNumber.ToLower().Contains(searchText);

                bool matchesFilters =
                    (string.IsNullOrEmpty(selectedManufacturer) || equipment.Manufacturer == selectedManufacturer) &&
                    (isTodaySelected || !selectedPurchaseDate.HasValue || equipment.PurchaseDate.Date == selectedPurchaseDate.Value.Date) &&
                    (string.IsNullOrEmpty(selectedStatus) || equipment.Status == selectedStatus);

                return matchesSearch && matchesFilters;
            }
            return false;
        }


        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _collectionView.Refresh();
        }

        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _collectionView.Refresh();
        }

        private void Page_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (EquipmentDataGrid.SelectedItem != null)
            {
                EquipmentDataGrid.SelectedItem = null;
            }
        }

        private void EquipmentDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (UserClass.RoleID == 4 && EquipmentDataGrid.SelectedItem is Equipment selectedEquipment)
            {
                // Проверяем, что оборудование в статусе "Рабочее" или "Неисправное"
                if (selectedEquipment.Status == "Рабочее" || selectedEquipment.Status == "Неисправное")
                {
                    var createRequestWindow = new EditRepairRequestWindow(null, selectedEquipment);
                    createRequestWindow.ShowDialog();
                    LoadEquipment(); // Обновляем список после создания заявки
                }
                else
                {
                    MessageBox.Show("Заявку можно создать только для оборудования в статусе 'Рабочее' или 'Неисправное'", 
                        "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }
}
