﻿using ClosedXML.Excel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using System.IO;


namespace WPFEquipmentK.Windows
{
    /// <summary>
    /// Логика взаимодействия для ReportsWindow.xaml
    /// </summary>
    public partial class ReportsWindow : Window
    {
        public ReportsWindow()
        {
            InitializeComponent();
            LoadEquipment();
        }
        private void LoadEquipment()
        {
            using (var db = new Diplom7Entities())
            {
                EquipmentComboBox.ItemsSource = db.Equipment.ToList();
                EquipmentComboBox.SelectedIndex = 0; // Выбираем первый элемент по умолчанию
            }
        }

        private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentComboBox.SelectedItem is Equipment selectedEquipment &&
                StartDatePicker.SelectedDate.HasValue &&
                EndDatePicker.SelectedDate.HasValue)
            {
                DateTime startDate = StartDatePicker.SelectedDate.Value;
                DateTime endDate = EndDatePicker.SelectedDate.Value;

                if (startDate > endDate)
                {
                    MessageBox.Show("Дата начала не может быть позже даты окончания!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                GenerateExcelReport(selectedEquipment, startDate, endDate);
            }
            else
            {
                MessageBox.Show("Выберите оборудование и диапазон дат!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void GenerateExcelReport(Equipment equipment, DateTime startDate, DateTime endDate)
        {
            using (var db = new Diplom7Entities())
            {
                var requests = db.RepairRequests
                    .Where(r => r.EquipmentID == equipment.EquipmentID &&
                                r.RequestDate >= startDate &&
                                r.RequestDate <= endDate)
                    .ToList();

                if (requests.Count == 0)
                {
                    MessageBox.Show("Нет заявок за указанный период.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // Получаем путь к рабочему столу
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = System.IO.Path.Combine(desktopPath, $"Отчет_{equipment.EquipmentName}_{DateTime.Now:yyyy-MM-dd_HH-mm}.xlsx");

                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Отчет");

                    // Заголовки столбцов
                    worksheet.Cell(1, 1).Value = "ID заявки";
                    worksheet.Cell(1, 2).Value = "Описание";
                    worksheet.Cell(1, 3).Value = "Дата заявки";
                    worksheet.Cell(1, 4).Value = "Статус";
                    worksheet.Cell(1, 5).Value = "Исполнитель";
                    worksheet.Cell(1, 6).Value = "Создатель";

                    // Оформление заголовков
                    var headerRange = worksheet.Range("A1:F1");
                    headerRange.Style.Font.Bold = true;
                    headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    headerRange.Style.Fill.BackgroundColor = XLColor.LightGray;

                    int row = 2;
                    foreach (var request in requests)
                    {
                        worksheet.Cell(row, 1).Value = request.RequestID;
                        worksheet.Cell(row, 2).Value = request.Description;
                        worksheet.Cell(row, 3).Value = request.RequestDate.ToShortDateString();
                        worksheet.Cell(row, 4).Value = request.Status;

                        // Получаем имя исполнителя (если назначен)
                        var assignedUser = db.Users.FirstOrDefault(u => u.UserID == request.AssignedTo);
                        worksheet.Cell(row, 5).Value = assignedUser != null ? assignedUser.UserName : "Не назначен";

                        // Получаем имя пользователя, который создал заявку
                        var createdByUser = db.Users.FirstOrDefault(u => u.UserID == request.RequestedBy);
                        worksheet.Cell(row, 6).Value = createdByUser != null ? createdByUser.UserName : "Неизвестно";

                        row++;
                    }

                    // Добавляем рамку (границы) ко всей таблице
                    var tableRange = worksheet.Range($"A1:F{row - 1}");
                    tableRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thick; // Внешняя рамка
                    tableRange.Style.Border.InsideBorder = XLBorderStyleValues.Thin;   // Внутренние линии

                    worksheet.Columns().AdjustToContents(); // Автоматическое подстраивание ширины колонок
                    workbook.SaveAs(filePath);
                }

                MessageBox.Show($"Отчет успешно сохранен на рабочем столе:\n{filePath}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

    }
}
