﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFEquipmentK.Helpers
{
    internal class AppConnect
    {
        public static Diplom7Entities ConnectDB = new Diplom7Entities();
        public static EmailService emailService = new EmailService();
    }
}
