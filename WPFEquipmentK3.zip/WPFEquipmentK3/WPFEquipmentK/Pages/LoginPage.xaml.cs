﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using WPFEquipmentK.Windows;

namespace WPFEquipmentK.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
       
        public LoginPage()
        {
            InitializeComponent();
  
        }
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {

            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            string hashedPassword = HashPassword(password);

            var db = AppConnect.ConnectDB;
            var user = db.Users.FirstOrDefault(u => u.UserName == username && u.PasswordHash == hashedPassword);

            if (user != null)
            {
                MessageBox.Show("Вход выполнен успешно!");
                UsernameTextBox.Text = null;
                PasswordBox.Password = null;
                UserClass.userID = user.UserID;
                UserClass.userName = user.UserName;
                UserClass.password = user.PasswordHash;
                UserClass.email = user.Email;
                UserClass.RoleID = user.RoleID;
                this.NavigationService.Navigate(new MenuPage());

            }
            else
            {
                MessageBox.Show("Неверное имя пользователя или пароль.");
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow regWindow = new RegistrationWindow();
            regWindow.Show();
        }

        private void UsernameTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Блокируем ввод пробела
            }
        }

        private void PasswordBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Блокируем ввод пробела
            }
        }
    }
}
