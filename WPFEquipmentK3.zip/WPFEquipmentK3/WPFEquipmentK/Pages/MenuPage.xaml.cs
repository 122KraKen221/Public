﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFEquipmentK.Helpers;
using WPFEquipmentK.Windows;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using System.Diagnostics;
using A = DocumentFormat.OpenXml.Drawing;
using Xdr = DocumentFormat.OpenXml.Drawing.Spreadsheet;
using A14 = DocumentFormat.OpenXml.Office2010.Drawing;

namespace WPFEquipmentK.Pages
{
    /// <summary>
    /// Логика взаимодействия для MenuPage.xaml
    /// </summary>
    public partial class MenuPage : System.Windows.Controls.Page
    {
        
        public MenuPage()
        {
            InitializeComponent();
            
            // Скрываем кнопку логов для всех кроме администратора
            if (UserClass.RoleID != 1)
            {
                LogsButton.Visibility = Visibility.Collapsed;
            }

            // Показываем кнопку заявок только для администратора (1), менеджера (2) и техника (3)
            if (UserClass.RoleID != 1 && UserClass.RoleID != 2 && UserClass.RoleID != 3)
            {
                BtnRepairRequest.Visibility = Visibility.Collapsed;
            }
        }

        private void EquipmentButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new EquipmentPage());
        }

        private void RepairRequestsButton_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.FrmObj.Navigate(new RepairRequestPage());
        }

        private void RepairsButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new GanttChartPage());
        }

        private void ReportsButton_Click(object sender, RoutedEventArgs e)
        {
            ReportsWindow reportsWindow = new ReportsWindow();
            reportsWindow.ShowDialog();
        }

        private void LogsButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new LogsPage());
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.FrmObj.Navigate(new LoginPage());
        }

    }
}
